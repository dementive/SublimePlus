# User Settings

These are the user settings that I use with sublime

They all have .bak in the file name so sublime doesn't read them, to use remove .bak from file name and put the files in the User folder